



<svg id="_1" data-name="1" xmlns="http://www.w3.org/2000/svg" width="70" height="110" viewBox="0 0 70 110">
  <defs>
    <style>
      .cls-1 {
        fill: #00af92;
        stroke: #00af92;
        stroke-width: 1px;
      }
    </style>
  </defs>
  <circle class="cls-1" cx="2.5" cy="107.5" r="2.5"/>
  <circle id="Ellipse_1_copy" data-name="Ellipse 1 copy" class="cls-1" cx="16.5" cy="107.5" r="2.5"/>
  <circle id="Ellipse_1_copy_2" data-name="Ellipse 1 copy 2" class="cls-1" cx="35.5" cy="107.5" r="2.5"/>
  <circle id="Ellipse_1_copy_3" data-name="Ellipse 1 copy 3" class="cls-1" cx="50.5" cy="107.5" r="2.5"/>
  <circle id="Ellipse_1_copy_4" data-name="Ellipse 1 copy 4" class="cls-1" cx="66.5" cy="107.5" r="2.5"/>
  <circle class="cls-1" cx="2.5" cy="92.5" r="2.5"/>
  <circle id="Ellipse_1_copy-2" data-name="Ellipse 1 copy" class="cls-1" cx="16.5" cy="92.5" r="2.5"/>
  <circle id="Ellipse_1_copy_2-2" data-name="Ellipse 1 copy 2" class="cls-1" cx="35.5" cy="92.5" r="2.5"/>
  <circle id="Ellipse_1_copy_3-2" data-name="Ellipse 1 copy 3" class="cls-1" cx="50.5" cy="92.5" r="2.5"/>
  <circle id="Ellipse_1_copy_4-2" data-name="Ellipse 1 copy 4" class="cls-1" cx="66.5" cy="92.5" r="2.5"/>
  <circle class="cls-1" cx="2.5" cy="76.5" r="2.5"/>
  <circle id="Ellipse_1_copy-3" data-name="Ellipse 1 copy" class="cls-1" cx="16.5" cy="76.5" r="2.5"/>
  <circle id="Ellipse_1_copy_2-3" data-name="Ellipse 1 copy 2" class="cls-1" cx="35.5" cy="76.5" r="2.5"/>
  <circle id="Ellipse_1_copy_3-3" data-name="Ellipse 1 copy 3" class="cls-1" cx="50.5" cy="76.5" r="2.5"/>
  <circle id="Ellipse_1_copy_4-3" data-name="Ellipse 1 copy 4" class="cls-1" cx="66.5" cy="76.5" r="2.5"/>
  <circle class="cls-1" cx="2.5" cy="58.5" r="2.5"/>
  <circle id="Ellipse_1_copy-4" data-name="Ellipse 1 copy" class="cls-1" cx="16.5" cy="58.5" r="2.5"/>
  <circle id="Ellipse_1_copy_2-4" data-name="Ellipse 1 copy 2" class="cls-1" cx="35.5" cy="58.5" r="2.5"/>
  <circle id="Ellipse_1_copy_3-4" data-name="Ellipse 1 copy 3" class="cls-1" cx="50.5" cy="58.5" r="2.5"/>
  <circle id="Ellipse_1_copy_4-4" data-name="Ellipse 1 copy 4" class="cls-1" cx="66.5" cy="58.5" r="2.5"/>
  <circle class="cls-1" cx="2.5" cy="43.5" r="2.5"/>
  <circle id="Ellipse_1_copy-5" data-name="Ellipse 1 copy" class="cls-1" cx="16.5" cy="43.5" r="2.5"/>
  <circle id="Ellipse_1_copy_2-5" data-name="Ellipse 1 copy 2" class="cls-1" cx="35.5" cy="43.5" r="2.5"/>
  <circle id="Ellipse_1_copy_3-5" data-name="Ellipse 1 copy 3" class="cls-1" cx="50.5" cy="43.5" r="2.5"/>
  <circle id="Ellipse_1_copy_4-5" data-name="Ellipse 1 copy 4" class="cls-1" cx="66.5" cy="43.5" r="2.5"/>
  <circle class="cls-1" cx="2.5" cy="28.5" r="2.5"/>
  <circle id="Ellipse_1_copy-6" data-name="Ellipse 1 copy" class="cls-1" cx="16.5" cy="28.5" r="2.5"/>
  <circle id="Ellipse_1_copy_2-6" data-name="Ellipse 1 copy 2" class="cls-1" cx="35.5" cy="28.5" r="2.5"/>
  <circle id="Ellipse_1_copy_3-6" data-name="Ellipse 1 copy 3" class="cls-1" cx="50.5" cy="28.5" r="2.5"/>
  <circle id="Ellipse_1_copy_4-6" data-name="Ellipse 1 copy 4" class="cls-1" cx="66.5" cy="28.5" r="2.5"/>
  <circle class="cls-1" cx="2.5" cy="15.5" r="2.5"/>
  <circle id="Ellipse_1_copy-7" data-name="Ellipse 1 copy" class="cls-1" cx="16.5" cy="15.5" r="2.5"/>
  <circle id="Ellipse_1_copy_2-7" data-name="Ellipse 1 copy 2" class="cls-1" cx="35.5" cy="15.5" r="2.5"/>
  <circle id="Ellipse_1_copy_3-7" data-name="Ellipse 1 copy 3" class="cls-1" cx="50.5" cy="15.5" r="2.5"/>
  <circle id="Ellipse_1_copy_4-7" data-name="Ellipse 1 copy 4" class="cls-1" cx="66.5" cy="15.5" r="2.5"/>
  <circle class="cls-1" cx="2.5" cy="3.5" r="2.5"/>
  <circle id="Ellipse_1_copy-8" data-name="Ellipse 1 copy" class="cls-1" cx="16.5" cy="3.5" r="2.5"/>
  <circle id="Ellipse_1_copy_2-8" data-name="Ellipse 1 copy 2" class="cls-1" cx="35.5" cy="3.5" r="2.5"/>
  <circle id="Ellipse_1_copy_3-8" data-name="Ellipse 1 copy 3" class="cls-1" cx="50.5" cy="3.5" r="2.5"/>
  <circle id="Ellipse_1_copy_4-8" data-name="Ellipse 1 copy 4" class="cls-1" cx="66.5" cy="3.5" r="2.5"/>
</svg>
